# Notes App (Frontend + Supabase)

## Setup

1. Host this on GitHub Pages.
2. Create a Supabase project.
3. Add a table called `notes` with columns:
   - `id` (UUID, primary key)
   - `title` (Text)
   - `category` (Text)
   - `content` (Text)
   - `created_at` (timestamp with default now())
4. Replace `SUPABASE_URL` and `SUPABASE_KEY` in `js/api.js`

## Pages
- `index.html`: Search notes
- `admin.html`: Add new notes
